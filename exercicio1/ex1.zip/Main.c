#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "FileHandler.h"



int main(){

    createBinaryStudentFile();
    populateStudentFile();
    getLastTenStudents();

    
}



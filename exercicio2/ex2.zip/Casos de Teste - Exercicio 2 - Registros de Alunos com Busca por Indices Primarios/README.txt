Arquivo zip gerado em: 19/04/2022 15:58:03 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 2 - Registros de Alunos com Busca por Índices Primários